//function like(id) {
  //  likes[id]++;
  //  spans[id].innerHTML = likes[id] + "like(s)";
  //  alert("user has liked ",likes+1,);
//}
  /*/if( element = document.body) {
    var element =  element.classList.toggle("dark-mode");
  }
 
  else if (element = document.body) {
var element =  element.classList.toggle("purple");
  }
  
  else if (element = document.body) {
    var element =  element.classList.toggle("blue");
  }
  
  else{
    var element =  element.classList.toggle("yellow");
  }

/*function myFunction() {
  var element = document.body;
  element.classList.toggle("purple");
}
function myFunction() {
  var element = document.body;
  element.classList.toggle("blue");
}
function myFunction() {
  var element = document.body;
  element.classList.toggle("yellow");
  
}*/
console.log("page loading...")
function myFunction() {
  var colors = document.getElementById("p1");
  colors.classList.toggle("purple")
  var colors = document.getElementById("p2");
  colors.classList.toggle("red")
  var colors = document.getElementById("p3");
  colors.classList.toggle("blue")
  var colors = document.getElementById("p3p");
  colors.classList.toggle("pink")
  var colors = document.getElementById("p4");
  colors.classList.toggle("yellow")
  var colors = document.getElementById("p5");
  colors.classList.toggle("dark-mode")

}



